from typing import List

from pydantic import BaseModel

from Backend.app.models.parsed_page import ParsedPage


class ParsedDocument(BaseModel):

    filename: str

    pages: List[ParsedPage]