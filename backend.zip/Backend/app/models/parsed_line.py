from pydantic import BaseModel


class ParsedLine(BaseModel):

    text: str

    font_size: float

    font_name: str

    x: float

    y: float

    is_bold: bool = False