from pydantic import BaseModel


class Paragraph(BaseModel):

    heading: str

    page: int

    lines: list[str]