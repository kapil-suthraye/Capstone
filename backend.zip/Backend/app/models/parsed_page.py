from typing import List

from pydantic import BaseModel

from Backend.app.models.parsed_line import ParsedLine


class ParsedPage(BaseModel):

    page_number: int

    lines: List[ParsedLine]