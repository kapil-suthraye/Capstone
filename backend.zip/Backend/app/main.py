from fastapi import FastAPI

from fastapi.middleware.cors import CORSMiddleware

from Backend.app.api.router import api_router

from Backend.app.core.config import settings

app=FastAPI(
    title="Medical AI Reviewer",
    version="1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS.split(","),
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True
)

app.include_router(api_router,prefix="/api")

@app.get("/")
async def root():
    return {"status":"running"}