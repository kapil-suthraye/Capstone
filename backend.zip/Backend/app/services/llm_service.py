class LLMService:

    async def evaluate(self,prompt,context):

        ...