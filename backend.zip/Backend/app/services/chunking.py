from Backend.app.models.document_chunk import DocumentChunk

from Backend.app.models.paragraph import Paragraph

from Backend.app.models.parsed_document import ParsedDocument

from Backend.app.utils.heading_detector import HeadingDetector

from Backend.app.services.token_counter import count_tokens


class Chunker:

    MAX_TOKENS = 700

    OVERLAP = 75

    def chunk_document(
        self,
        document: ParsedDocument
    ):

        paragraphs = self.build_paragraphs(document)

        chunks = []

        for paragraph in paragraphs:

            chunks.extend(

                self.chunk_paragraph(

                    paragraph,

                    document.filename

                )

            )

        return chunks
    
    def build_paragraphs(
        self,
        document
    ):

        paragraphs = []

        heading = "General"

        buffer = []

        page = 1

        for parsed_page in document.pages:

            page = parsed_page.page_number

            for line in parsed_page.lines:

                if HeadingDetector.is_heading(line):

                    if buffer:

                        paragraphs.append(

                            Paragraph(

                                heading=heading,

                                page=page,

                                lines=buffer

                            )

                        )

                    heading = line.text

                    buffer = []

                else:

                    if line.text.strip():

                        buffer.append(line.text)

        if buffer:

            paragraphs.append(

                Paragraph(

                    heading=heading,

                    page=page,

                    lines=buffer

                )

            )

        return paragraphs
    
    def chunk_paragraph(
        self,
        paragraph,
        filename
    ):

        chunks = []

        current = []

        tokens = 0

        for line in paragraph.lines:

            t = count_tokens(line)

            if tokens + t > self.MAX_TOKENS:

                text = "\n".join(current)

                chunks.append(

                    DocumentChunk(

                        text=text,

                        page_start=paragraph.page,

                        page_end=paragraph.page,

                        source_file=filename,

                        document_category="Medical Record",

                        section_heading=paragraph.heading,

                        token_count=tokens

                    )

                )

                current = current[-10:]

                tokens = count_tokens("\n".join(current))

            current.append(line)

            tokens += t

        if current:

            chunks.append(

                DocumentChunk(

                    text="\n".join(current),

                    page_start=paragraph.page,

                    page_end=paragraph.page,

                    source_file=filename,

                    document_category="Medical Record",

                    section_heading=paragraph.heading,

                    token_count=tokens

                )

            )

        return chunks
    
