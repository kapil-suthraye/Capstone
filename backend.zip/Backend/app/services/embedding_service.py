from openai import OpenAI

from Backend.app.core.config import settings

class EmbeddingService:

    def __init__(self):

        self.client = OpenAI(
            api_key=settings.OPENAI_API_KEY
        )

    def embed(self,text):

        response = self.client.embeddings.create(

            model=settings.OPENAI_EMBEDDING_MODEL,

            input=text

        )

        return response.data[0].embedding