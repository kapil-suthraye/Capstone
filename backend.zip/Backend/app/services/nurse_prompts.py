from pydantic import BaseModel

class NursePrompt(BaseModel):

    id:str

    category:str

    diagnosis:str

    question:str