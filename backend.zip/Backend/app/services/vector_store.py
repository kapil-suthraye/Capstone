from pinecone import Pinecone

from Backend.app.core.config import settings

from Backend.app.services.embedding_service import EmbeddingService

class VectorStore:

    def __init__(self):

        self.pc = Pinecone(
            api_key=settings.PINECONE_API_KEY
        )

        self.index = self.pc.Index(
            settings.PINECONE_INDEX_NAME
        )

        self.embedder = EmbeddingService()
    
    def upsert_chunks(self, chunks):

        vectors = []

        for chunk in chunks:

            embedding = self.embedder.embed(chunk.text)

            vectors.append({
                "id": chunk.id,
                "values": embedding,
                "metadata": {
                    "text": chunk.text,

                    # Updated fields
                    "page_start": chunk.page_start,
                    "page_end": chunk.page_end,

                    "heading": chunk.section_heading,
                    "source": chunk.source_file,
                    "category": chunk.document_category,
                    "chunk_type": chunk.chunk_type,

                    "section_path": chunk.section_path,

                    "token_count": chunk.token_count,

                    "diagnosis_tag": chunk.metadata.get("diagnosis_tag")
                }
            })

        response = self.index.upsert(vectors=vectors)

        print(f"Upserted {len(vectors)} vectors")
        print(response)

    def similarity_search(

        self,

        query,

        diagnosis=None,

        top_k=20

    ):

        embedding=self.embedder.embed(query)

        filter_dict={}

        if diagnosis:

            filter_dict["diagnosis_tag"]={
                "$eq":diagnosis
            }

        result=self.index.query(

            vector=embedding,

            top_k=top_k,

            include_metadata=True,

            filter=filter_dict if filter_dict else None

        )
        
        print("Matches:", len(result.matches))

        return result.matches
    
    def rerank(

        self,

        query,

        matches,

        top_n=5

    ):

        documents=[]

        for match in matches:

            documents.append(

                match.metadata["text"]

            )

        reranked=self.pc.inference.rerank(

            model="bge-reranker-v2-m3",

            query=query,

            documents=documents,

            top_n=top_n

        )

        return reranked